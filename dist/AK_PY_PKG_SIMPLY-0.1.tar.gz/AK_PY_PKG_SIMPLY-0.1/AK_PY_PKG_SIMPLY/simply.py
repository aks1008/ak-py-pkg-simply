if __name__ == "__main__":

    class Simply():

        def simplyText(self):
            print('Nice')
            return 'Simply Text Return'
