class Simplfy():

    def simplfyText(self):
        '''
        Returns simply text
        '''
        return 'Simply Text Return'
