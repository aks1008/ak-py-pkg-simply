import simply

user = simply.Simplfy()
print(user.simplfyText())